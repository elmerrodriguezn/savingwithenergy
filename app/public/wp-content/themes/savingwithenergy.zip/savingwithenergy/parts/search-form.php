<form class="form-group-search" action="/" method="get">
    <i class="fas fa-search"></i>
    <input class="form-control form-control-search" type="text" name="s" id="search" value="<?php the_search_query(); ?>" placeholder="Search"/>
</form>