<nav class="pagination-custom" aria-label="Page navigation">
    <?php echo paginate_links(); ?>
</nav>
