<?php get_header(); ?>
<div class="container container-posts">
    <div class="card card-post">
        <div class="card-body"> <h3 class="title">Page not found</h3>
            <div class="content-404">
                <i class="far fa-frown fa-10x"></i>
                <h3 class="text-404">Why don't you try searching?</h3>
                <?php include('parts/search-form.php') ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
