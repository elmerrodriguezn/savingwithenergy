<?php /* Template Name: Building-Green Page */ ?>
<?php get_header();?>
<div class="container container-posts">
    <div class="card card-post">
        <div class="card-body">
            <h1>HOW TO START?</h1>
            <ul>
                <li>SUBMIT YOUR ENERGY INVOICE</li>
                <li>INSTALL CLOUD CARE SYSTEM</li>
                <li>GET INTERNATIONAL EXPERTS ANALISYS</li>
                <li>C.A.S.H. REPORT!</li>
            </ul>

            <div>
                <p>USE LESS ENERGY GET MORE CASH</p>
                <p>+1,300 WORLD WIDE CASES OF SUCCESS!</p>
            </div>
            <div>Logos</div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
